"""Exact toroidal minimum distance by ternary DIFFERENCE vectors.

For C = {mG (mod q) : m in {0,1}^k}, every difference of two
messages lies in {-1,0,1}^k, and every such difference is realizable.
Therefore d_T(C)^2 = min{w_T(vG mod q)^2 : v in {-1,0,1}^k,
                                   w_T(vG mod q)^2 > 0}.

Because v and -v have identical toroidal weights, this program
checks only difference vectors whose first nonzero entry is +1.

Edit q and G in the section below, then run:
    python compute_toroidal_distance_differences.py
Requires Python 3; no external packages.
"""

from itertools import product
from math import isqrt
from time import perf_counter

# ====================== USER INPUT ======================
q = 4
G = [
    [1,0,0,0,0,0,0,0, 2,1,1,1,1,1,1,1],
    [0,1,0,0,0,0,0,0, 1,2,3,1,2,1,0,0],
    [0,0,1,0,0,0,0,0, 1,0,2,3,1,2,1,0],
    [0,0,0,1,0,0,0,0, 1,0,0,2,3,1,2,1],
    [0,0,0,0,1,0,0,0, 1,1,0,0,2,3,1,2],
    [0,0,0,0,0,1,0,0, 1,2,1,0,0,2,3,1],
    [0,0,0,0,0,0,1,0, 1,1,2,1,0,0,2,3],
    [0,0,0,0,0,0,0,1, 1,3,1,2,1,0,0,2],
]
# ========================================================


def validate():
    if not isinstance(q, int) or q < 2:
        raise ValueError("q must be an integer >= 2")
    if not G or not G[0] or any(len(row) != len(G[0]) for row in G):
        raise ValueError("G must be a nonempty rectangular matrix")
    if any(not isinstance(x, int) for row in G for x in row):
        raise ValueError("G must contain integers")


def encode(vector):
    """Compute vG modulo q for a row vector v."""
    return tuple(sum(v * G[i][j] for i, v in enumerate(vector)) % q
                 for j in range(len(G[0])))


def weight_squared(vector):
    """Squared toroidal weight of a vector with entries in [0,q-1]."""
    return sum(min(x, q - x)**2 for x in vector)


def signed_differences(k):
    """Represent each pair {v,-v} once, excluding the all-zero vector."""
    for v in product((-1, 0, 1), repeat=k):
        if next((x for x in v if x != 0), 0) == 1:
            yield v


def witness_messages(v):
    """Find binary m,m' satisfying m-m'=v coordinatewise."""
    m = tuple(1 if x == 1 else 0 for x in v)
    m_prime = tuple(1 if x == -1 else 0 for x in v)
    return m, m_prime


def main():
    validate()
    t0 = perf_counter()
    k, n = len(G), len(G[0])
    best_sq, best_vector, best_codeword = None, None, None
    checked = 0
    zero_difference = None
    minimizers = 0

    for v in signed_differences(k):
        checked += 1
        c = encode(v)
        d2 = weight_squared(c)
        if d2 == 0:
            # Distinct messages can produce the same codeword.
            if zero_difference is None:
                zero_difference = v
            continue
        if best_sq is None or d2 < best_sq:
            best_sq, best_vector, best_codeword = d2, v, c
            minimizers = 1
        elif d2 == best_sq:
            minimizers += 1

    if best_sq is None:
        raise ValueError("The code has only one distinct codeword")

    # For this binary-message construction, cardinality can be checked
    # separately without doing any pairwise codeword comparisons.
    count = len({encode(m) for m in product((0, 1), repeat=k)})
    m, m_prime = witness_messages(best_vector)
    root = isqrt(best_sq)
    distance = str(root) if root * root == best_sq else f"sqrt({best_sq})"

    print(f"q = {q}; k = {k}; n = {n}")
    print(f"number of distinct codewords |C| = {count}")
    print(f"checked ternary difference vectors (up to sign) = {checked}")
    print(f"number of minimizers (up to sign) = {minimizers}")
    print(f"minimum squared toroidal distance d_T(C)^2 = {best_sq}")
    print(f"minimum toroidal distance d_T(C) = {distance} ({best_sq**0.5:.10f})")
    print(f"v = m-m' = {best_vector}")
    print(f"vG mod q = {best_codeword}")
    print(f"m  = {m}")
    print(f"m' = {m_prime}")
    print(f"mG mod q  = {encode(m)}")
    print(f"m'G mod q = {encode(m_prime)}")
    if zero_difference is not None:
        print("Note: binary messages are NOT injectively encoded; zero differences were excluded.")
        print(f"Collision difference v = {zero_difference}")
    else:
        print("Binary-message encoding is injective.")
    print(f"elapsed time = {perf_counter() - t0:.6f} s")


if __name__ == "__main__":
    main()
